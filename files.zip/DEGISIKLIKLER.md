# bugtool — Neler Düzeltildi?

Bu belge, koda bakmadan neyin bozuk olduğunu ve neyin düzeltildiğini anlaman için.
Tüm dosya adları aynı kaldı — eski kurulumunun üzerine bu dosyaları koyman yeterli.

Her düzeltme, çalıştırılabilir testlerle doğrulandı (aşağıda "Nasıl doğrulandı"
bölümünde detay var) — sadece "olması lazım" diye yazılmadı, gerçekten çalıştırılıp
kanıtlandı.

---

## Öncelik 0 — Kapsam (scope) güvenliği

Bunların hepsi aynı sorunu paylaşıyordu: bug bounty programının izin vermediği bir
hedefin yine de test edilebilmesi.

**1. `scope.txt` dosyasına satır-içi not düşünce, o satır sessizce işe yaramıyordu.**
Örneğin `!admin.example.com  # buna dokunma` yazdığında, eski kod yorum dahil tüm
satırı "yasaklı host" olarak kaydediyordu — ama gerçek dünyada hiçbir host böyle
garip bir isme sahip olamayacağı için bu yasak asla tetiklenmiyordu. `admin.example.com`
sessizce test edilebilir kalıyordu. Artık `#` işaretinden sonrası (satır başında da,
satır içinde de) doğru şekilde temizleniyor.

**2. Beklenmedik bir hata olduğunda araç "kapsamda say" diyordu, olması gereken tam tersiydi.**
Kapsam kontrolü bir yerde beklenmedik şekilde hata verirse (örneğin çok garip bir
URL geldiğinde), eski kod bu hedefi güvenli tarafta değil, "test edilebilir" tarafta
sayıyordu. Bir güvenlik kontrolünün hata durumunda yapması gereken şey her zaman
"izin verme" olmalı — artık öyle davranıyor.

**3. `scope.txt` dosyasını hiç oluşturmamış olsan bile `--active` (canlı test) komutu susarak çalışıyordu.**
Bu en can alıcı olanıydı. Araç kendini "kapsam olmadan asla aktif test yapmam"
diye tanımlıyor ama pratikte: taze bir kurulumda `scope.txt` dosyası henüz yoksa,
eski kod bunu fark edip sadece SARI (görmezden gelinebilir) bir uyarı basıyor ve
YİNE DE devam ediyordu. Yani "kapsam tanımsız" durumunda araç fiilen kapsamsız
çalışıyordu. Artık `scope.txt` gerçekten var ve dolu değilse (ya da config.yaml'da
hedef listesi girilmemişse), araç KIRMIZI bir mesajla durur ve hiçbir istek
göndermeden çıkar.

---

## Öncelik 1 — kendi bilgisayarına karşı risk

**4. Hedef ismi (`example.com` gibi) bir komut satırına doğrudan ekleniyordu.**
`subfinder`, `nuclei`, `ffuf` gibi dış araçları çalıştırırken, hedef adı komut
metnine ham şekilde ekleniyordu. Eğer bu isim (elle yazarken bir yazım hatasıyla,
ya da ileride bir listeden/otomasyondan okunarak) noktalı virgül veya benzeri
özel karakterler içerseydi, o karakterden sonrası ayrı bir komut olarak
çalıştırılabilirdi — yani kendi bilgisayarında istenmeyen bir komut yürüyebilirdi.
Artık komutlar bu şekilde yorumlanmıyor; hedef ismi her zaman düz bir metin olarak
kalıyor, ne yazarsan yaz bir komut olarak çalıştırılmıyor.

---

## Öncelik 2 — bulguları kaçırma / yanlış bulgu riski

**5. Bir istek zaman aşımına uğrarsa, o bulgu tamamen kayboluyordu.**
Bazı zafiyet türleri (SQLi, komut enjeksiyonu) "sunucuyu N saniye beklet" diyerek
test edilir — sunucu gerçekten bekliyorsa bu bir kanıttır. Ama sunucu ÇOK uzun
beklerse (yapılandırılan zaman aşımını aşarsa), eski kod bunu "bilinmeyen hata"
sayıp tamamen görmezden geliyordu — oysa bu aslında EN GÜÇLÜ kanıttı. Artık zaman
aşımı da bir kanıt olarak değerlendiriliyor.

**6. Genel bir hata sayfası gösteren sitelerde SQLi yanlış pozitif üretebiliyordu.**
Bazı siteler her istekte (gönderdiğin şeyden bağımsız) genel bir hata sayfası
gösterir. Eski kod bunu payload'dan bağımsız kontrol etmiyordu — böyle bir sitede
neredeyse her parametre "SQLi bulundu" olarak işaretlenebilirdi. Artık payload
göndermeden önceki normal cevapla (baseline) kıyaslanıyor; aynı hata zaten
baseline'da da varsa sayılmıyor.

**7. SSRF tespitinde anlamsız/hatalı bir imza vardı.**
Listedeki imzalardan biri ("ail=1") hiçbir bilinen bulut-metadata formatına karşılık
gelmiyordu ve çok kısa olduğu için tamamen alakasız bir metinde bile (örn. bir
e-posta adresinin içinde) yanlışlıkla eşleşebilirdi. Kaldırıldı.

**8. Teknoloji versiyonu tespiti çok fazla gürültü üretiyordu.**
Neredeyse her sitede bulunan jQuery, Bootstrap gibi kütüphanelerin versiyon
numarası bile "ilginç" olarak işaretleniyordu — bu da gerçekten değerli olan
sunucu/altyapı yazılımı (nginx, Apache gibi) versiyon bilgisini gürültü içinde
kaybettiriyordu. Artık sadece sunucu tarafı sinyaller bu şekilde işaretleniyor.

**9. İstek bütçesi, en olası hedeflere göre değil, keşif sırasına göre harcanıyordu.**
Parametre adı hiçbir ipucu vermiyorsa (örn. "value", "data") eski kod TÜM zafiyet
sınıflarını deniyordu — bu da sınırlı istek bütçesinin ilk birkaç sıradan
parametrede tükenip, sonradan bulunan gerçekten ilginç bir endpoint'e hiç sıra
gelmemesine yol açabiliyordu. Artık ipucu bulunan hedefler önce test ediliyor,
ipucu olmayan parametrelerde de sadece en değerli 3 sınıf (XSS/SQLi/açık
yönlendirme) deneniyor — istersen `config.yaml`'dan eski davranışa dönebilirsin.

---

## Öncelik 3 — veri kalitesi

**10-11. nuclei ve ffuf çıktıları artık düzenli (JSON) formatta okunuyor.**
Eskiden bu iki aracın "insan için" yazdığı düz metin çıktısı tahminle
ayrıştırılıyordu — bazı durumlarda (örn. bir zafiyetin ekstra bilgi çıkardığı
template'lerde) hangi metnin hedef URL olduğu yanlış tahmin edilebiliyordu, ffuf'ta
ise bulunan yolun durum kodu (200 mü 403 mü) tamamen kayboluyordu. Artık her ikisi
de yapılandırılmış veri formatında okunuyor; daha güvenilir ve tekrar üretilebilir
bulgular (nuclei için doğrudan çalıştırılabilir bir `curl` komutu dahil).

---

## Öncelik 4-5 — performans ve görünürlük

**12. Binlerce istek gönderirken her seferinde yeni bağlantı açılıyordu.** Artık
aynı bağlantı yeniden kullanılıyor — hem daha hızlı hem hedefe daha az yük.

**13. Sertifika doğrulaması kapalıyken konsol uyarılarla doluyordu.** Artık
susturuluyor (doğrulamanın kapalı olması bilinçli bir tercih zaten).

**14. Bir araç (subfinder, nuclei…) sessizce çökerse, "0 sonuç bulundu" ile "araç
kırıldı" arasındaki fark görünmüyordu.** Artık bir aşama çalışıp hata verirse
kırmızı bir uyarı olarak gösteriliyor.

**15. Discord/Slack/Teams bildirimi başarısız olursa hiç haber verilmiyordu.**
Artık başarılı/başarısız olduğu ekrana yazılıyor. Ayrıca **Microsoft Teams'in eski
webhook formatı Mayıs 2026'da kalıcı olarak kapatıldı** — Teams bildirimi
kullanacaksan Teams'te kanal → Workflows menüsünden yeni bir webhook adresi alman
gerekiyor, eski adres artık hiçbir şey göndermez (bunu `config.yaml` içine de not
olarak ekledim).

**16. Bir asset artık canlı değilse ya da bir bulgu kayboluyorsa (yama yapıldı
gibi) bu hiç görünmüyordu, sadece "yeni" olanlar gösteriliyordu.** Artık
"artık canlı olmayan host" ve "artık görünmeyen bulgu" da ayrıca gösteriliyor.

**17. Bazı bilinen hassas dosya adları (terraform.tfstate, web.config, SSH
anahtarları, .npmrc gibi) tespit listesinde yoktu.** Eklendi.

---

## Nasıl doğrulandı

Her madde için ayrı ayrı, gerçek Python kodu çalıştırılarak test edildi — sadece
"böyle olmalı" denip bırakılmadı. Örnekler: sahte bir `scope.txt` dosyasına
satır-içi yorumlu bir kural yazıp gerçekten engellendiğini gördüm; komut
enjeksiyonu denemesi yaptım ve artık çalışmadığını doğruladım; sahte bir zaman
aşımı oluşturup bulgunun artık kaybolmadığını gördüm; boş bir `scope.txt` ile
`--active` komutunu tetikleyip gerçekten kırmızı mesajla durduğunu gördüm.
Dış araçların kendisi (subfinder, nuclei, ffuf, httpx…) bu ortamda kurulu
olmadığı için onların ürettiği GERÇEK verilerle uçtan uca deneyemedim — ama
kodun mantığını, dış araçların resmi dokümantasyonundan doğrulanmış çıktı
formatlarıyla test ettim.

**Öneri:** dosyaları kendi ortamına koyduktan sonra, önce zararsız bir hedefte
(örn. kendi sahibi olduğun bir test sitesi) `python main.py recon <hedef>` ile
tek bir tur dene, sonra `--active`'e geç.

---

## Kurulum (kod bilmesen de yapabilirsin)

1. Bu dosyaları eski `bugtool` klasörünün üzerine kopyala (aynı isimler,
   üzerine yazacaksın).
2. Terminalde proje klasörüne gir, şunu çalıştır:
   `pip install -r requirements.txt`
3. `scope.txt` dosyanın gerçekten dolu olduğundan emin ol (Öncelik 0'daki 3.
   madde — artık bu olmadan `--active` çalışmıyor).
4. Her zamanki gibi çalıştır: `python main.py hunt <hedef>` ya da
   `python main.py recon <hedef>`.

---

## Şimdilik dokunulmayanlar (istersen sonra konuşuruz)

Bunlar bug değildi, yeni yetenek fikirleriydi — bu turda bilerek dışarıda
bırakıldı: JS dosyalarından secret/API-key tarama modülü, POST/JSON gövdesi
fuzzing, hedef 403/429 dönmeye başlarsa geri çekilme, HTML/Markdown rapor
çıktısı. Hazır olduğunda konuşuruz.
