"""bugtool — bug bounty asset recon + monitor + triage + aktif test kütüphanesi.

Tamamen deterministik: hiçbir modül LLM çağırmaz. AI yalnızca ÇIKTIYI analiz
etmek için (sohbet arayüzünde, ayrı bir adım olarak) kullanılır.
"""
